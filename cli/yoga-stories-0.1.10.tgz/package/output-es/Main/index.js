import * as Data$dFunctor from "../Data.Functor/index.js";
import * as Data$dShow from "../Data.Show/index.js";
import * as Effect$dAff from "../Effect.Aff/index.js";
import * as Effect$dConsole from "../Effect.Console/index.js";
import * as Node$dEncoding from "../Node.Encoding/index.js";
import * as Node$dFS$dAff from "../Node.FS.Aff/index.js";
import * as Node$dFS$dAsync from "../Node.FS.Async/index.js";
import * as Node$dFS$dPerms from "../Node.FS.Perms/index.js";
import * as Type$dProxy from "../Type.Proxy/index.js";
import * as Unsafe$dCoerce from "../Unsafe.Coerce/index.js";
import * as Yoga$dJSON from "../Yoga.JSON/index.js";
import * as YogaStories$dResolution from "../YogaStories.Resolution/index.js";
import * as YogaStories$dServer from "../YogaStories.Server/index.js";
const writeJSON = /* #__PURE__ */ Yoga$dJSON.writeJSON(/* #__PURE__ */ (() => {
  const $0 = Yoga$dJSON.writeForeignFieldsCons({reflectSymbol: () => "exports"})({writeImpl: xs => Data$dFunctor.arrayMap(Unsafe$dCoerce.unsafeCoerce)(xs)})(Yoga$dJSON.writeForeignFieldsCons({
    reflectSymbol: () => "moduleName"
  })(Yoga$dJSON.writeForeignString)(Yoga$dJSON.writeForeignFieldsCons({reflectSymbol: () => "sourceCode"})(Yoga$dJSON.writeForeignString)(Yoga$dJSON.writeForeignFieldsCons({
    reflectSymbol: () => "sourcePath"
  })(Yoga$dJSON.writeForeignString)(Yoga$dJSON.writeForeignFieldsNilRowR)()()())()()())()()())()()();
  return {writeImpl: xs => Data$dFunctor.arrayMap(rec => $0.writeImplFields(Type$dProxy.Proxy)(rec)({}))(xs)};
})());
const main = /* #__PURE__ */ (() => {
  const $0 = Effect$dAff._makeFiber(
    Effect$dAff.ffiUtil,
    Effect$dAff._bind(YogaStories$dResolution.discoverStories({outputDir: "./output", include: ["**.Stories"], exclude: []}))(stories => Effect$dAff._bind(Effect$dAff._liftEffect(Effect$dConsole.log("Discovered " + Data$dShow.showIntImpl(stories.length) + " story modules")))(() => Effect$dAff._bind(Node$dFS$dAff.toAff2(Node$dFS$dAsync.mkdir$p)("./dist")({
      recursive: true,
      mode: Node$dFS$dPerms.permsAll
    }))(() => Effect$dAff._bind(Node$dFS$dAff.toAff2(Node$dFS$dAsync.readTextFile)(Node$dEncoding.UTF8)("./static/index.html"))(indexHtml => Effect$dAff._bind(Node$dFS$dAff.toAff3(Node$dFS$dAsync.writeTextFile)(Node$dEncoding.UTF8)("./dist/index.html")(indexHtml))(() => Effect$dAff._bind(Node$dFS$dAff.toAff3(Node$dFS$dAsync.writeTextFile)(Node$dEncoding.UTF8)("./dist/stories.json")(writeJSON(stories)))(() => Effect$dAff._bind(Effect$dAff._liftEffect(Effect$dConsole.log("Wrote dist/index.html and dist/stories.json")))(() => Effect$dAff._bind(YogaStories$dServer.startServer({
      distDir: "./dist"
    })(9010))(() => Effect$dAff.never))))))))
  );
  return () => {
    const fiber = $0();
    fiber.run();
  };
})();
export {main, writeJSON};
