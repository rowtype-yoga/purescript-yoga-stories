import "@fontsource/jetbrains-mono";
import "./code-viewer.js";
import "virtual:yoga-stories-head";
import moduleRegistry from "virtual:yoga-stories-modules";

if (Object.keys(moduleRegistry).length > 0) {
  window.__yogaStoriesModuleRegistry = moduleRegistry;
}

if (!window.__yogaStoriesInitialised) {
  window.__yogaStoriesInitialised = true;
  const { clientMain } = await import("/output/YogaStories.UI.Client/index.js");
  clientMain();
}

if (import.meta.hot) {
  import.meta.hot.accept();
  import.meta.hot.on("yoga-stories:module-update", ({ moduleName }) => {
    window.__yogaStoriesHMR?.(moduleName);
  });
  import.meta.hot.on("yoga-stories:stories-update", () => {
    window.__yogaStoriesRefreshStories?.();
  });
}
